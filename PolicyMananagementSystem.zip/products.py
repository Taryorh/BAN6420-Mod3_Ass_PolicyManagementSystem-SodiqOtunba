from custom_logger import CustomLogger
import os


log_directory = os.path.join(os.path.dirname(__file__), 'logs')  # Assuming the logs are in a 'logs' folder
log_path = os.path.join(log_directory, 'policy_management_log.log')

# Check if the log file exists, raise an error if it doesn't
if not os.path.exists(log_path):
    raise FileNotFoundError("Log file 'policy_management_log.log' not found in the 'logs' directory")

custom_logger = CustomLogger(log_path)
custom_logger.initialize_logger()


class ProductError(Exception):
    """Custom exception class for product-related errors."""
    pass


class Product:
    product_list = []  # Class-level list to store all registered products

    def __init__(self, product_id, name, description, price, currency="₦"):
        if not isinstance(product_id, int) or product_id <= 0:
            custom_logger.logger.error("Invalid product ID. It must be a positive integer.")
            raise ValueError("Invalid product ID. It must be a positive integer.")
        if not isinstance(name, str) or not name.strip():
            custom_logger.logger.error("Invalid product name. It must be a non-empty string.")
            raise ValueError("Invalid product name. It must be a non-empty string.")
        if not isinstance(description, str):
            custom_logger.logger.error("Invalid product description. It must be a string.")
            raise ValueError("Invalid product description. It must be a string.")
        if not isinstance(price, (int, float)) or price < 0:
            custom_logger.logger.error("Invalid price. It must be a non-negative number.")
            raise ValueError("Invalid price. It must be a non-negative number.")
        if not isinstance(currency, str) or len(currency) != 1:
            custom_logger.logger.error("Invalid currency. It must be a single character representing the currency symbol.")
            raise ValueError("Invalid currency. It must be a single character representing the currency symbol.")

        self.product_id = product_id
        self.name = name
        self.description = description
        self.price = price
        self.currency = currency  # Default currency is Naira (₦)

    @classmethod
    def product_exists(cls, product_id):
        """Check if a product with the given product_id exists."""
        try:
            return any(prod for prod in cls.product_list if prod.product_id == product_id)
        except Exception as e:
            custom_logger.logger.error(f"Error checking product existence: {e}")
            raise ProductError(f"Error checking product existence: {e}")

    def add_product(self):
        """Add the product to the registered product list if it doesn't already exist."""
        try:
            if Product.product_exists(self.product_id):
                custom_logger.logger.error(f"Product '{self.name}' with ID {self.product_id} already exists.")
                raise ProductError(f"Product '{self.name}' with ID {self.product_id} already exists.")
            else:
                Product.product_list.append(self)
                custom_logger.logger.info(f"Product '{self.name}' added successfully.")
                print(f"Product '{self.name}' added successfully.")
        except ProductError as pe:
            custom_logger.logger.error(f"Add product error: {pe}")
            print(f"Add product error: {pe}")
        except Exception as e:
            custom_logger.logger.error(f"An unexpected error occurred while adding product: {e}")
            print(f"An unexpected error occurred while adding product: {e}")

    @classmethod
    def remove_product(cls, product_id):
        """Remove a product from the registered product list by product_id."""
        try:
            for prod in cls.product_list:
                if prod.product_id == product_id:
                    cls.product_list.remove(prod)  # Remove the product from the list
                    custom_logger.logger.info(f"Product '{prod.name}' with ID {product_id} removed successfully.")
                    print(f"Product '{prod.name}' with ID {product_id} removed successfully.")
                    return
            custom_logger.logger.error(f"Product with ID {product_id} not found.")
            raise ProductError(f"Product with ID {product_id} not found.")
        except ProductError as pe:
            custom_logger.logger.error(f"Remove product error: {pe}")
            print(f"Remove product error: {pe}")
        except Exception as e:
            custom_logger.logger.error(f"An unexpected error occurred while removing product: {e}")
            print(f"An unexpected error occurred while removing product: {e}")

    @classmethod
    def display_products(cls):
        """Display all the products in the product list with prices in Naira."""
        try:
            if not cls.product_list:
                custom_logger.logger.error("No products are registered.")
                print("No products are registered.")
            else:
                print("Registered Products:")
                for prod in cls.product_list:
                    # Display product with price formatted to include Naira sign
                    print(f" - {prod.name} (ID: {prod.product_id}, Price: {prod.currency}{prod.price:.2f})")
        except Exception as e:
            custom_logger.logger.error(f"An unexpected error occurred while displaying products: {e}")
            print(f"An unexpected error occurred while displaying products: {e}")
