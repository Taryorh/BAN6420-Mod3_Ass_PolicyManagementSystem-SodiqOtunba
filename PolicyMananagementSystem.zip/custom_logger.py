import logging

class CustomLogger:
    def __init__(self, log_path):
        self.log_path = log_path
        self.logger = self.initialize_logger()
        
        
    def initialize_logger(self):
        log_format = "%(asctime)s %(levelname)s %(message)s"
        logging.basicConfig(filename=self.log_path, format=log_format, filemode='a')
        logger = logging.getLogger()

        logger.setLevel(logging.INFO)
        return logger