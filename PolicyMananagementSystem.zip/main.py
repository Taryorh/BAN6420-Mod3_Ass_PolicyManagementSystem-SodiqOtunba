from policyholder import PolicyHolder
from products import Product
from payments import Payment
from custom_logger import CustomLogger
import os


log_directory = os.path.join(os.path.dirname(__file__), 'logs')  # Assuming the logs are in a 'logs' folder
log_path = os.path.join(log_directory, 'policy_management_log.log')

# Check if the log file exists, raise an error if it doesn't
if not os.path.exists(log_path):
    raise FileNotFoundError("Log file 'policy_management_log.log' not found in the 'logs' directory")

custom_logger = CustomLogger(log_path)
custom_logger.initialize_logger()


# Get names for two policyholders
policyholder_names = input("Please enter the names of two policyholders, separated by a comma: ").split(",")

# Ensure there are exactly two policyholder names
if len(policyholder_names) != 2:
    custom_logger.logger.error("Please provide exactly two policyholder names.")
    print("Please provide exactly two policyholder names.")
else:
    # Trim whitespace and create policyholders
    policyholder1 = PolicyHolder(name=policyholder_names[0].strip())
    policyholder2 = PolicyHolder(name=policyholder_names[1].strip())

    # Register them and get unique IDs
    policyholder_id1 = policyholder1.register()
    policyholder_id2 = policyholder2.register()

    # Check if registration succeeded before proceeding
    if policyholder_id1 and policyholder_id2:
        # Create different products for each policyholder
        product1 = Product(product_id=101, name="Life Insurance", description="Basic life insurance plan", price=500)
        product2 = Product(product_id=102, name="Health Insurance", description="Premium health insurance plan", price=1500)

        # Add products to product list
        product1.add_product()
        product2.add_product()

        # Assign different products to each policyholder
        policyholder1.add_product(product1)
        policyholder2.add_product(product1)

        # Process different payments for each policyholder
        payment1 = Payment(payment_id=102, policyholder_id=policyholder_id1, amount=500)
        payment2 = Payment(payment_id=112, policyholder_id=policyholder_id2, amount=1500)

        payment1.process_payment()
        payment2.process_payment()

        # Display policyholder details for both policyholders
        print("\nPolicyholder 1 details:")
        policyholder1.display_details()

        print("\nPolicyholder 2 details:")
        policyholder2.display_details()
    else:
        custom_logger.logger.error("Error: Failed to register both policyholders.")
        print("Error: Failed to register both policyholders.")
