import random
from custom_logger import CustomLogger
import os

random.seed(123)



log_directory = os.path.join(os.path.dirname(__file__), 'logs')  # Assuming the logs are in a 'logs' folder
log_path = os.path.join(log_directory, 'policy_management_log.log')

# Check if the log file exists, raise an error if it doesn't
if not os.path.exists(log_path):
    raise FileNotFoundError("Log file 'policy_management_log.log' not found in the 'logs' directory")

custom_logger = CustomLogger(log_path)
custom_logger.initialize_logger()

class PolicyholderError(Exception):
    """Custom exception class for policyholder-related errors."""
    pass


class PolicyHolder:
    policyholder_list = []  # Class-level list to store all registered policyholders

    def __init__(self, name):
        if not name or not isinstance(name, str):
            custom_logger.logger.custom_logger.logger.error("Invalid name. Name must be a non-empty string.")
            raise ValueError("Invalid name. Name must be a non-empty string.")
        self.policyholder_id = None  # Will be generated when registering
        self.name = name
        self.status = None  # Will be set to "Active" upon registration
        self.products = []

    @classmethod
    def policyholder_exists(cls, name):
        """Check if the policyholder's name already exists."""
        try:
            return any(ph for ph in cls.policyholder_list if ph.name.lower() == name.lower())
        except Exception as e:
            custom_logger.logger.error(f"Error checking policyholder existence: {e}")
            raise PolicyholderError(f"Error checking policyholder existence: {e}")

    @classmethod
    def generate_policyholder_id(cls):
        """Generate a unique policyholder ID."""
        try:
            while True:
                policyholder_id = random.randint(1000, 9999)
                if not any(ph for ph in cls.policyholder_list if ph.policyholder_id == policyholder_id):
                    return policyholder_id
        except Exception as e:
            custom_logger.logger.error(f"Error generating policyholder ID: {e}")
            raise PolicyholderError(f"Error generating policyholder ID: {e}")

    def register(self):
        """Register the policyholder if they don't already exist and assign an auto-generated policy number."""
        try:
            if PolicyHolder.policyholder_exists(self.name):
                custom_logger.logger.error((f"Policyholder '{self.name}' already exists."))  
                raise PolicyholderError(f"Policyholder '{self.name}' already exists.")
            else:
                self.policyholder_id = PolicyHolder.generate_policyholder_id()
                self.status = "Active"
                PolicyHolder.policyholder_list.append(self)
                custom_logger.logger.info(f"Registered policyholder {self.name} with ID {self.policyholder_id}")
                print(f"Registered policyholder {self.name} with ID {self.policyholder_id}")
                return self.policyholder_id 
        except PolicyholderError as pe:
            custom_logger.logger.error(f"Registration error: {pe}")
            print(f"Registration error: {pe}")
        except Exception as e:
            custom_logger.logger.error(f"An unexpected error occurred during registration: {e}")
            print(f"An unexpected error occurred during registration: {e}")

    def suspend(self):
        """Suspend a policyholder by setting their status to 'Suspended'."""
        try:
            if not self.policyholder_id:
                custom_logger.logger.error("Policyholder is not registered.")
                raise PolicyholderError("Policyholder is not registered.")
            if self.status == "Suspended":
                custom_logger.logger.error(f"Policyholder {self.name} is already suspended.")
                raise PolicyholderError(f"Policyholder {self.name} is already suspended.")
            self.status = "Suspended"
            custom_logger.logger.info(f"Suspended policyholder {self.name}")
            print(f"Suspended policyholder {self.name}")
        except PolicyholderError as pe:
            custom_logger.logger.error(f"Suspension error: {pe}")
            print(f"Suspension error: {pe}")
        except Exception as e:
            custom_logger.logger.error(f"An unexpected error occurred while suspending: {e}")
            print(f"An unexpected error occurred while suspending: {e}")

    def reactivate(self):
        """Reactivate a suspended policyholder by setting their status back to 'Active'."""
        try:
            if not self.policyholder_id:
                custom_logger.logger.error("Policyholder is not registered.")
                raise PolicyholderError("Policyholder is not registered.")
            if self.status == "Active":
                custom_logger.logger.error(f"Policyholder {self.name} is already active.")
                raise PolicyholderError(f"Policyholder {self.name} is already active.")
            self.status = "Active"
            custom_logger.logger.info(f"Reactivated policyholder {self.name}")
            print(f"Reactivated policyholder {self.name}")
        except PolicyholderError as pe:
            custom_logger.logger.error(f"Reactivation error: {pe}")
            print(f"Reactivation error: {pe}")
        except Exception as e:
            custom_logger.logger.error(f"An unexpected error occurred while reactivating: {e}")
            print(f"An unexpected error occurred while reactivating: {e}")

    def add_product(self, product):
        """Add a product to the policyholder if it's not already registered."""
        try:
            if not self.policyholder_id:
                custom_logger.logger.error("Policyholder is not registered.")
                raise PolicyholderError("Policyholder is not registered.")
            if any(prod for prod in self.products if prod.product_id == product.product_id):
                custom_logger.logger.error(f"Product '{product.name}' is already registered for policyholder {self.name}")
                raise PolicyholderError(f"Product '{product.name}' is already registered for policyholder {self.name}")
            self.products.append(product)
            custom_logger.logger.info(f"Added product '{product.name}' to policyholder {self.name}'s account")
            print(f"Added product '{product.name}' to policyholder {self.name}'s account")
        except PolicyholderError as pe:
            custom_logger.logger.error(f"Product addition error: {pe}")
            print(f"Product addition error: {pe}")
        except Exception as e:
            custom_logger.logger.error(f"An unexpected error occurred while adding the product: {e}")
            print(f"An unexpected error occurred while adding the product: {e}")

    def display_details(self):
        """Display the policyholder's details, including registered products."""
        try:
            if not self.policyholder_id:
                custom_logger.logger.error("Policyholder is not registered.")
                raise PolicyholderError("Policyholder is not registered.")
            print('-'*30)
            print(f"Policyholder: {self.name} (ID: {self.policyholder_id})")
            print(f"Status: {self.status}")
            print("Products:")
            
            if not self.products:
                custom_logger.logger.error(" - No products registered")
                print(" - No products registered")
                print('-'*30)
            else:
                for product in self.products:
                    print(f" - {product.name}")
                    print('-'*30)
                    print('\n')
        except PolicyholderError as pe:
            custom_logger.logger.error(f"Display error: {pe}")
            print(f"Display error: {pe}")
        except Exception as e:
            custom_logger.logger.error(f"An unexpected error occurred while displaying details: {e}")
            print(f"An unexpected error occurred while displaying details: {e}")
