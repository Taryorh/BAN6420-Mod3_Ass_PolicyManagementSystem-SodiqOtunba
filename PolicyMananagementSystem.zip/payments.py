from custom_logger import CustomLogger
import os


log_directory = os.path.join(os.path.dirname(__file__), 'logs')  # Assuming the logs are in a 'logs' folder
log_path = os.path.join(log_directory, 'policy_management_log.log')

# Check if the log file exists, raise an error if it doesn't
if not os.path.exists(log_path):
    raise FileNotFoundError("Log file 'policy_management_log.log' not found in the 'logs' directory")

custom_logger = CustomLogger(log_path)
custom_logger.initialize_logger()


class PaymentError(Exception):
    """Custom exception for payment-related errors."""
    pass


class Payment:
    payment_list = []  # Class-level list to store all payments made

    def __init__(self, payment_id, policyholder_id, amount, status="Pending"):
        self.payment_id = payment_id
        self.policyholder_id = policyholder_id
        self.amount = amount
        self.status = status

    @classmethod
    def payment_exists(cls, payment_id):
        """Check if a payment with the given payment_id already exists."""
        return any(payment for payment in cls.payment_list if payment.payment_id == payment_id)

    def process_payment(self):
        """Process the payment and handle potential errors."""
        try:
            # Check if payment ID already exists
            if Payment.payment_exists(self.payment_id):
                custom_logger.logger.error(f"Payment with ID {self.payment_id} already exists.")
                raise PaymentError(f"Payment with ID {self.payment_id} already exists.")

            # Validate the amount (ensure it's greater than zero)
            if self.amount <= 0:
                custom_logger.logger.error(f"Invalid payment amount: {self.amount}. Amount must be greater than zero.")
                raise PaymentError(f"Invalid payment amount: {self.amount}. Amount must be greater than zero.")

            # Simulate payment processing (here, we'll assume it's successful)
            self.status = "Completed"
            Payment.payment_list.append(self)
            custom_logger.logger.info(f"Payment of {self.amount:.2f} naira for Policyholder {self.policyholder_id} processed successfully.")
            print(f"Payment of ₦{self.amount:.2f} for Policyholder {self.policyholder_id} processed successfully.")

        except PaymentError as e:
            custom_logger.logger.error(f"Payment Error: {e}")
            print(f"Payment Error: {e}")
        except Exception as e:
            custom_logger.logger.error(f"An unexpected error occurred: {e}")
            print(f"An unexpected error occurred: {e}")

    @classmethod
    def remind_payment(cls, policyholder_id):
        """Send a reminder for pending payments."""
        try:
            pending_payments = [payment for payment in cls.payment_list if payment.policyholder_id == policyholder_id and payment.status == "Pending"]
            if not pending_payments:
                custom_logger.logger.info(f"No pending payments for Policyholder {policyholder_id}.")
                raise PaymentError(f"No pending payments for Policyholder {policyholder_id}.")
            
            # Simulate sending a reminder
            custom_logger.logger.info(f"Reminder sent for Policyholder {policyholder_id} with pending payments")
            print(f"Reminder: Policyholder {policyholder_id}, you have {len(pending_payments)} pending payment(s).")
        except PaymentError as e:
            custom_logger.logger.error(f"Payment Reminder Error: {e}")
            print(f"Payment Reminder Error: {e}")
        except Exception as e:
            custom_logger.logger.error(f"An unexpected error occurred while sending reminders: {e}")
            print(f"An unexpected error occurred while sending reminders: {e}")

    @classmethod
    def apply_penalty(cls, policyholder_id, penalty_amount):
        """Apply a penalty to policyholder's pending payments."""
        try:
            if penalty_amount <= 0:
                custom_logger.logger.error(f"Penalty amount must be greater than zero. Given: {penalty_amount}")
                raise PaymentError(f"Penalty amount must be greater than zero. Given: {penalty_amount}")

            pending_payments = [payment for payment in cls.payment_list if payment.policyholder_id == policyholder_id and payment.status == "Pending"]
            if not pending_payments:
                custom_logger.logger.error(f"No pending payments for Policyholder {policyholder_id} to apply penalty.")
                raise PaymentError(f"No pending payments for Policyholder {policyholder_id} to apply penalty.")

            # Apply penalty by increasing the amount for each pending payment
            for payment in pending_payments:
                payment.amount += penalty_amount
                custom_logger.logger.info(f"A penalty of ₦{penalty_amount:.2f} has been applied to Policyholder {policyholder_id}'s pending payments.")
            print(f"A penalty of ₦{penalty_amount:.2f} has been applied to Policyholder {policyholder_id}'s pending payments.")
        except PaymentError as e:
            custom_logger.logger.error(f"Penalty Error: {e}")
            print(f"Penalty Error: {e}")
        except Exception as e:
            custom_logger.logger.error(f"An unexpected error occurred while applying the penalty: {e}")
            print(f"An unexpected error occurred while applying the penalty: {e}")

    @classmethod
    def display_payments(cls):
        """Display all the payments in the system."""
        if not cls.payment_list:
            print("No payments have been made.")
        else:
            print("Payments List:")
            for payment in cls.payment_list:
                print(f"Payment ID: {payment.payment_id}, Policyholder ID: {payment.policyholder_id}, Amount: ₦{payment.amount:.2f}, Status: {payment.status}")
